let mysql2 = require('mysql');

const config_mysql = {
    user:'vcms_user',
    password:'Vcms_user@2022',
    database:'vcms_dev',
    host:'192.168.100.208',
    port:13306,
}

const connection = mysql2.createPool(config_mysql)

module.exports = connection;